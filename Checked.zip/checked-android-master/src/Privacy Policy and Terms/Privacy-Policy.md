**Privacy Policy**

The Checked App is built by Peter D'Pong as an Open Source App. The SERVICE is provided by Peter D'Pong at no cost and is intented to be used as is.
This Page is to inform users of policies with collection, use, and discolsure of Personal Information if anyone decides to use my Service.
Peter D'Pong built the Checked app as an Open Source app. This SERVICE is provided by Peter D'Pong at no cost and is intended for use as is.
By using this Service, you agree to thecollection and use of information in relation to this policy. The Personal Information that I collect is used soley for providing and improving this Service. I will not use or share your information with anyone except as described in this Privacy Policy.

**Information Collection and Use**
The service does not collect any information and all tasks are stored locally on the Device and wil not be collected/accessible by in in any way.
This app does use third part services that may collect information used to identify you.
*   [Google Play Services](https://www.google.com/policies/privacy/)

**Log Data**

When using my Service, in a case of any error or crash in the app, I collect data and information (through thrid party products) on your phone called Log Data. This Log Data may include information such as your device's Internet Protocol ("IP") address, device name, operating system version, the configuration of the app, the time and date of the use of the Service, and other statistics.

**Cookies**

Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. 
These are sent to your browser from the websites that you visit and are stored on your device's internal memory. 
This Service does not use "cookies" explicitly. The app may use third party code and libraries that use these "cookies" to collect information and improve their services. You have the option to either accept or refuse these cookies and know when a cookie is being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions of this Service.

**Security**
I value your trust in provding us with any of your Personal Information, thus I am striving to use commercially acceptable means of protecting it. Please remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and I cannot guarantee absolute secruity. 
All task information and data inputted into the Service is stored locally on the Device and never transmitted.

**Links to Other Sites**
This Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by me. Therefore, I strongly advise you to review the Privacy Policy of these websites. I have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.

**Changes to This Privacy Policy**

I may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. I will notify you of any changes by posting the new Privacy Policy on this page.

This policy is effective as of 2020-06-18

**Contact Us**
If you have any questions or suggestions about my Privacy Policy, contact me at peterdpongdev@gmail.com.

